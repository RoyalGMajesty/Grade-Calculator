import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the student's name: ");
        String name = input.nextLine();
        
        System.out.print("Enter the student's grade: ");
        double grade = input.nextDouble();
        
        if (grade >= 90) {
            System.out.println(name + " has an A.");
        } else if (grade >= 80) {
            System.out.println(name + " has a B.");
        } else if (grade >= 70) {
            System.out.println(name + " has a C.");
        } else if (grade >= 60) {
            System.out.println(name + " has a D.");
        } else {
            System.out.println(name + " has an F.");
        }
    }
}